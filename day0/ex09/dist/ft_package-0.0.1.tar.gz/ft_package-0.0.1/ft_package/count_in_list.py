def count_in_list(lst, value) -> int:
    return lst.count(value)
